<?php
// susunan  file : pertemuan_11/model/model_anggota.php
 
function openDbConnection() {
    $link = new PDO("mysql:host=localhost;dbname=belajar", "root", "");
    return $link;
}
function closedBConnection(&$link) {
    $link = null;
}
function getAnggota() {
    $link = openDbConnection();
    $result = $link-> query("SELECT * FROM anggota");
    $anggota = array();
    while ($row =$result->fetch(PDO::FETCH_ASSOC)){
        $anggota[]= $row;

    }
    closedBConnection($link);
    return $anggota;
}